import { prisma } from '../config/db.js';

/**
 * Format a DB ClinicalNote record to match frontend expectations
 */
const formatNote = (n) => {
  if (!n) return null;
  return {
    id: n.id,
    patientId: n.patientId,
    patientName: n.patient ? `${n.patient.firstName} ${n.patient.lastName}`.trim() : 'Unknown Patient',
    selectedInjuryAreas: n.patient?.selectedInjuryAreas || [],
    caseId: n.caseId,
    providerId: n.providerId,
    providerName: n.provider?.name || 'Unknown Provider',
    type: n.noteType,
    noteType: n.noteType,
    title: n.title,
    date: n.date,
    status: n.status,
    author: n.author,
    signedBy: n.signedBy,
    signedAt: n.signedAt,
    signatureUrl: n.signatureUrl,
    soapSubjective: n.soapSubjective || '',
    soapObjective: n.soapObjective || '',
    soapAssessment: n.soapAssessment || '',
    soapPlan: n.soapPlan || '',
    anatomicalDiagramData: n.anatomicalDiagramData || '',
    content: typeof n.content === 'string' ? JSON.parse(n.content) : n.content || {},
    addendums: typeof n.addendums === 'string' ? JSON.parse(n.addendums) : n.addendums || [],
    createdAt: n.createdAt
  };
};

/**
 * Get clinical notes list with optional filters
 */
export const getNotes = async (req, res) => {
  const { patientId, providerId, status, caseId, type } = req.query;

  try {
    const where = {};
    if (patientId) where.patientId = patientId;
    if (providerId) where.providerId = providerId;
    if (status) where.status = status;
    if (caseId) where.caseId = caseId;
    if (type) where.noteType = type;

    // Doctor role is restricted to Pain Management (prov-josmic) and Counseling (prov-counselor)
    if (req.doctorFilterAllowedOnly) {
      where.providerId = { in: ['prov-josmic', 'prov-counselor'] };
    }

    const notes = await prisma.clinicalNote.findMany({
      where,
      include: {
        patient: { select: { firstName: true, lastName: true, selectedInjuryAreas: true } },
        provider: { select: { name: true } }
      },
      orderBy: { createdAt: 'desc' }
    });

    return res.status(200).json(notes.map(formatNote));
  } catch (error) {
    console.error('Error fetching clinical notes:', error);
    return res.status(500).json({ error: 'Internal server error fetching notes.' });
  }
};

/**
 * Get clinical note by ID
 */
export const getNoteById = async (req, res) => {
  const { id } = req.params;

  try {
    const note = await prisma.clinicalNote.findUnique({
      where: { id },
      include: {
        patient: { select: { firstName: true, lastName: true, selectedInjuryAreas: true } },
        provider: { select: { name: true } }
      }
    });

    if (!note) {
      return res.status(404).json({ error: 'Clinical note not found.' });
    }

    return res.status(200).json(formatNote(note));
  } catch (error) {
    console.error('Error fetching note by ID:', error);
    return res.status(500).json({ error: 'Failed to retrieve clinical note.' });
  }
};

/**
 * Create clinical note draft
 */
export const createNote = async (req, res) => {
  const data = req.body;

  if (!data.patientId) {
    return res.status(400).json({ error: 'patientId is required.' });
  }

  const generatedId = `note-${Date.now()}`;
  const currentDateStr = new Date().toLocaleDateString('en-US');

  try {
    // 1. Verify patient exists or find by patientId
    let patient = await prisma.patient.findFirst({
      where: {
        OR: [{ id: data.patientId }, { patientId: data.patientId }]
      }
    });

    if (!patient) {
      patient = await prisma.patient.findFirst();
    }

    const patientId = patient ? patient.id : data.patientId;

    // 2. Resolve valid case for this patient
    let validCaseId = data.caseId;
    let existingCase = null;

    if (validCaseId) {
      existingCase = await prisma.case.findFirst({
        where: {
          OR: [{ id: validCaseId }, { caseId: validCaseId }]
        }
      });
    }

    if (!existingCase && patientId) {
      existingCase = await prisma.case.findFirst({
        where: { patientId }
      });
    }

    if (!existingCase && patientId) {
      const generatedCaseId = `case-${Date.now()}`;
      existingCase = await prisma.case.create({
        data: {
          id: generatedCaseId,
          caseId: `CASE-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
          patientId: patientId,
          accidentDate: new Date().toISOString().split('T')[0],
          accidentType: 'Motor Vehicle Collision',
          accidentState: 'TX',
          status: 'ACTIVE'
        }
      });
    }

    validCaseId = existingCase ? existingCase.id : 'case-001';

    // 3. Resolve provider
    let providerId = data.providerId || 'prov-josmic';
    const existingProvider = await prisma.provider.findUnique({
      where: { id: providerId }
    });
    if (!existingProvider) {
      const newProv = await prisma.provider.create({
        data: {
          id: providerId,
          name: data.providerName || 'New Practice Provider',
          businessName: 'F&M Health & Wellness',
          status: 'ACTIVE',
          isPlaceholder: true
        }
      });
      providerId = newProv.id;
    }

    const noteType = data.type || data.noteType || 'JOSMIC_PAIN';

    // 4. Resolve and validate appointment/visit association
    const appointmentId = data.appointmentId || data.content?.appointmentId;
    if (appointmentId) {
      const targetApt = await prisma.appointment.findUnique({
        where: { id: appointmentId }
      });
      if (targetApt && targetApt.patientId !== patientId) {
        return res.status(400).json({ error: 'Validation Error: This appointment visit does not belong to the selected patient.' });
      }

      // Check if an existing note is already linked to this visit
      let existingVisitNote = null;
      if (data.id) {
        existingVisitNote = await prisma.clinicalNote.findUnique({
          where: { id: data.id }
        });
      }
      if (!existingVisitNote) {
        const candidateNotes = await prisma.clinicalNote.findMany({
          where: {
            patientId,
            OR: [
              { providerId },
              { noteType }
            ]
          }
        });
        existingVisitNote = candidateNotes.find(n => {
          const parsed = typeof n.content === 'string' ? (() => { try { return JSON.parse(n.content); } catch(e){ return {}; } })() : (n.content || {});
          return parsed.appointmentId === appointmentId || (n.title && n.title.includes(appointmentId));
        });
      }

      if (existingVisitNote) {
        if (existingVisitNote.status === 'SIGNED_LOCKED' && !data.isAddendum) {
          return res.status(403).json({ error: 'This visit clinical note is already electronically signed and locked. It cannot be overwritten.' });
        }
        // Update draft note for this visit
        const updatedVisitNote = await prisma.clinicalNote.update({
          where: { id: existingVisitNote.id },
          data: {
            title: data.title || existingVisitNote.title,
            date: data.date || existingVisitNote.date,
            status: data.status || existingVisitNote.status,
            author: data.author || existingVisitNote.author,
            soapSubjective: data.soapSubjective || (data.content?.presentingConcerns || ''),
            soapObjective: data.soapObjective || (data.content?.clinicalObservations || ''),
            soapAssessment: data.soapAssessment || (data.content?.assessment || ''),
            soapPlan: data.soapPlan || (data.content?.followUpPlan || ''),
            content: { ...(typeof existingVisitNote.content === 'object' ? existingVisitNote.content : {}), ...data.content, appointmentId }
          },
          include: {
            patient: { select: { firstName: true, lastName: true, selectedInjuryAreas: true } },
            provider: { select: { name: true } }
          }
        });
        return res.status(200).json(formatNote(updatedVisitNote));
      }
    }

    // If saving an AI_DOCTOR_NOTE, update existing note for this case if present
    if (noteType === 'AI_DOCTOR_NOTE' && validCaseId) {
      const existingDocNote = await prisma.clinicalNote.findFirst({
        where: {
          caseId: validCaseId,
          noteType: 'AI_DOCTOR_NOTE'
        }
      });

      if (existingDocNote) {
        const updated = await prisma.clinicalNote.update({
          where: { id: existingDocNote.id },
          data: {
            title: data.title || existingDocNote.title,
            status: data.status || existingDocNote.status,
            author: data.author || existingDocNote.author,
            soapSubjective: data.soapSubjective || (data.content?.presentingConcerns || ''),
            soapObjective: data.soapObjective || (data.content?.objectiveExam || ''),
            soapAssessment: data.soapAssessment || (data.content?.diagnosticImpression || ''),
            soapPlan: data.soapPlan || (data.content?.treatmentPlan || ''),
            content: data.content || existingDocNote.content
          },
          include: {
            patient: { select: { firstName: true, lastName: true, selectedInjuryAreas: true } },
            provider: { select: { name: true } }
          }
        });
        return res.status(200).json(formatNote(updated));
      }
    }

    const newNote = await prisma.clinicalNote.create({
      data: {
        id: generatedId,
        patientId: patientId,
        caseId: validCaseId,
        providerId: providerId,
        noteType: noteType,
        title: data.title || 'Clinical Evaluation Note',
        date: data.date || currentDateStr,
        status: data.status || 'DRAFT',
        author: data.author || 'Attending Clinician',
        soapSubjective: data.soapSubjective || (data.content?.['Subjective (HPI)'] || ''),
        soapObjective: data.soapObjective || (data.content?.['Objective Findings'] || ''),
        soapAssessment: data.soapAssessment || (data.content?.['Clinical Assessment'] || ''),
        soapPlan: data.soapPlan || (data.content?.['Treatment Plan'] || ''),
        content: data.content || {},
        addendums: []
      },
      include: {
        patient: { select: { firstName: true, lastName: true, selectedInjuryAreas: true } },
        provider: { select: { name: true } }
      }
    });

    return res.status(201).json(formatNote(newNote));
  } catch (error) {
    console.error('Error creating clinical note:', error);
    return res.status(500).json({ error: 'Failed to create clinical note draft.', details: error.message });
  }
};

/**
 * Sign and lock clinical note
 */
export const signNote = async (req, res) => {
  const { id } = req.params;
  const { signatureUrl, authorName } = req.body;

  if (!signatureUrl) {
    return res.status(400).json({ error: 'signatureUrl is required to sign note.' });
  }

  try {
    const existing = await prisma.clinicalNote.findUnique({
      where: { id }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Clinical note not found.' });
    }

    const updated = await prisma.clinicalNote.update({
      where: { id },
      data: {
        status: 'SIGNED_LOCKED',
        signatureUrl,
        signedBy: authorName || 'Authorized Physician',
        signedAt: new Date(),
        author: authorName || existing.author
      },
      include: {
        patient: { select: { firstName: true, lastName: true, selectedInjuryAreas: true } },
        provider: { select: { name: true } }
      }
    });

    return res.status(200).json(formatNote(updated));
  } catch (error) {
    console.error('Error signing clinical note:', error);
    return res.status(500).json({ error: 'Failed to sign clinical note.' });
  }
};

/**
 * Amend note adding addendums
 */
export const amendNote = async (req, res) => {
  const { id } = req.params;
  const { addendumText, authorName } = req.body;

  if (!addendumText) {
    return res.status(400).json({ error: 'addendumText is required to amend note.' });
  }

  try {
    const existing = await prisma.clinicalNote.findUnique({
      where: { id }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Clinical note not found.' });
    }

    const currentAddendums = typeof existing.addendums === 'string' 
      ? JSON.parse(existing.addendums) 
      : existing.addendums || [];

    const newAddendum = {
      id: `addendum-${Date.now()}`,
      timestamp: new Date().toLocaleString(),
      author: authorName || 'Clinician',
      text: addendumText
    };

    const updated = await prisma.clinicalNote.update({
      where: { id },
      data: {
        status: 'AMENDED',
        addendums: [...currentAddendums, newAddendum]
      },
      include: {
        patient: { select: { firstName: true, lastName: true, selectedInjuryAreas: true } },
        provider: { select: { name: true } }
      }
    });

    return res.status(200).json(formatNote(updated));
  } catch (error) {
    console.error('Error amending clinical note:', error);
    return res.status(500).json({ error: 'Failed to amend clinical note.' });
  }
};

/**
 * Helper to compile diverse document payloads (objects or text) into structured medical context
 */
const compileClinicalDocumentation = (inputData) => {
  if (typeof inputData?.compiledDocumentation === 'string' && inputData.compiledDocumentation.trim()) {
    return inputData.compiledDocumentation.trim();
  }

  const context = inputData?.context;
  if (!context || typeof context !== 'object') {
    return 'No additional clinical records provided.';
  }

  const sections = [];
  for (const [docName, docData] of Object.entries(context)) {
    if (!docData) continue;
    sections.push(`=== DOCUMENT: ${docName.toUpperCase()} ===`);
    
    if (typeof docData === 'string') {
      sections.push(docData.trim());
    } else if (typeof docData === 'object') {
      for (const [k, v] of Object.entries(docData)) {
        if (v !== undefined && v !== null && v !== '') {
          if (typeof v === 'string' && v.startsWith('data:image')) continue;
          if (typeof v === 'object') {
            sections.push(`• ${k}: ${JSON.stringify(v)}`);
          } else {
            sections.push(`• ${k}: ${v}`);
          }
        }
      }
    }
    sections.push('');
  }

  return sections.length > 0 ? sections.join('\n') : 'No additional clinical records provided.';
};

/**
 * Generate AI SOAP suggested text drafts (Supports Live Gemini API, Groq, or Smart Clinical Template Engine)
 */
export const generateAiDraft = async (req, res) => {
  const promptType = req.body.promptType || req.body.noteType || req.body.type;
  const inputData = req.body.inputData || req.body;

  if (!promptType) {
    return res.status(400).json({ error: 'promptType is required.' });
  }

  const patientName = inputData?.patientName || 'Patient';
  const complaints = inputData?.complaints || inputData?.chiefComplaint || inputData?.mechanismOfInjury || (inputData?.accidentType ? `Injuries resulting from ${inputData.accidentType}` : 'Reported accident injuries');
  const locations = Array.isArray(inputData?.painLocations) ? inputData.painLocations.join(', ') : (inputData?.painLocations || inputData?.injuryBodyParts || 'Documented anatomical regions');
  const diag = inputData?.diagnosisCodes ? (Array.isArray(inputData.diagnosisCodes) ? inputData.diagnosisCodes.join(', ') : inputData.diagnosisCodes) : '';

  const compiledDocs = compileClinicalDocumentation(inputData);

  const geminiApiKey = process.env.GEMINI_API_KEY;
  const groqApiKey = process.env.GROQ_API_KEY;

  // Build prompt for live AI
  let aiPrompt = '';
  if (promptType === 'DOCTOR_NOTE') {
    aiPrompt = `You are a clinical documentation assistant for a personal injury and multi-specialty medical practice.
Your task is to compile and synthesize the provided patient clinical documentation into a structured Doctor's Note / Clinical Summary draft.

CRITICAL CLINICAL RULES:
1. Summarize and organize documented facts ONLY.
2. DO NOT fabricate or invent diagnoses, symptoms, treatments, dates, findings, medications, or other clinical facts not supported by the provided documentation.
3. If information for any section is not documented in the provided sources, explicitly state: "Information not documented in selected records." Do NOT invent filler data.
4. Output MUST be a strictly valid JSON object ONLY (no markdown code blocks, no explanation text) with these exact keys:
{
  "chiefComplaint": "...",
  "subjectiveHistory": "...",
  "objectiveFindings": "...",
  "clinicalAssessment": "...",
  "treatmentsAdministered": "...",
  "courseOfCare": "...",
  "treatmentPlan": "...",
  "followUp": "..."
}

PATIENT / CASE DEMOGRAPHICS:
- Patient Name: ${patientName}
- Date of Service / Review: ${inputData?.dos || new Date().toLocaleDateString()}
- Accident Date: ${inputData?.accidentDate || 'Documented in record'}
- Accident Type / Context: ${inputData?.accidentType || complaints}
- Primary Complaints: ${complaints}
- Injury Locations: ${locations}
- Documented Diagnosis Codes: ${diag || 'Refer to clinical documentation'}
- Referring / Attending Provider: ${inputData?.providerName || 'Attending Physician'}

COMPILED SOURCE CLINICAL DOCUMENTATION:
${compiledDocs}

Generate a clear, professional, structured clinical note adhering strictly to the facts above. Output pure JSON only.`;
  } else if (promptType === 'PAIN_MANAGEMENT') {
    aiPrompt = `You are an expert pain management physician documenting an initial consultation report for a personal injury patient.
Generate a valid JSON object ONLY (no markdown, no backticks) with these exact keys:
{
  "chiefComplaint": "Detailed narrative of accident mechanism, date, and chief complaints",
  "painDescription": ["Sharp", "Throbbing", "Radiating"],
  "painLocations": ["Neck", "L.Back", "R.Shoulder"],
  "painCurrent": 7,
  "painWorst": 9,
  "painBest": 4,
  "aggravatingFactors": ["Movement", "Sitting/Standing", "Bending", "Lifting"],
  "relievingFactors": ["Rest", "Ice/Heat", "Physical therapy"],
  "functionalLimitations": ["Difficulty sleeping", "Reduced daily activities"],
  "rosNeurologic": ["Tingling", "Numbness", "Headaches"],
  "rosMusculoskeletal": ["Joint stiffness", "Muscle spasms", "Limited range of motion"],
  "palpationTenderness": "Yes",
  "palpationMuscleSpasm": "Yes",
  "rom": "Limited - Painful",
  "neuroMotor": "Normal",
  "neuroSensory": "Intact",
  "neuroReflexes": "Normal",
  "diagnoses": ["S13.4", "S33.5", "M79.1", "M54.1"],
  "diagnosticsOrdered": ["MRI", "X-ray"],
  "medications": ["NSAIDs", "Muscle relaxants"],
  "interventions": ["Physical therapy", "Trigger point injections", "Laser therapy"],
  "restrictions": ["No lifting >10 lbs", "Limited bending/twisting"],
  "followUp": "2 weeks"
}
Patient: ${patientName}, Accident Date: ${inputData?.accidentDate || ''}, Context: ${complaints}, Locations: ${locations}, Diagnoses: ${diag}. Pure JSON only.`;
  } else if (promptType === 'TPI_ASSESSMENT') {
    aiPrompt = `You are a clinical physician assessing a personal injury patient for Trigger Point Injections.
Generate a valid JSON object ONLY (no markdown, no backticks) with these exact keys:
{
  "painScore": 7,
  "chiefComplaint": "Narrative of localized trigger point tenderness and pain following accident",
  "affectedMuscles": ["Trapezius (Bilateral)", "Levator Scapulae", "Rhomboids", "Quadratus Lumborum"],
  "palpationFindings": "Discrete hyperirritable taut bands with localized twitch response and radiating pain referral",
  "treatmentPlan": "Proceed with Trigger Point Injections (CPT 20552/20553) using 1% Lidocaine for local desensitization and stretching"
}
Patient: ${patientName}, Injury Context: ${complaints}, Locations: ${locations}. Pure JSON only.`;
  } else if (promptType === 'TPI_PROCEDURE') {
    aiPrompt = `You are an operating physician documenting a Trigger Point Injection Operative Procedure Report.
Generate a valid JSON object ONLY (no markdown, no backticks) with these exact keys:
{
  "preOpDiagnosis": "Myofascial pain syndrome (M79.1), Cervical sprain (S13.4), Lumbar strain (S33.5)",
  "medicationInjected": "1% Lidocaine (preservative-free), 4 mL total",
  "totalVolume": "4 mL total volume, 25-gauge 1.5-inch needle",
  "musclesInjected": [
    { "muscle": "Trapezius", "side": "Bilateral", "volume": "2.0 mL" },
    { "muscle": "Levator Scapulae", "side": "Left / Right", "volume": "1.0 mL" },
    { "muscle": "Quadratus Lumborum", "side": "Bilateral", "volume": "1.0 mL" }
  ],
  "procedureDescription": "Detailed operative technique describing aseptic prep with ChloraPrep, palpation of taut bands, aspiration negative for blood/fluid, injection with local twitch response, and patient tolerance."
}
Patient: ${patientName}, Context: ${complaints}, Locations: ${locations}, Diagnoses: ${diag}. Pure JSON only.`;
  } else if (promptType === 'COUNSELING_INDIVIDUAL_NOTE' || promptType === 'COUNSELOR_PROGRESS_NOTE') {
    const sessionDate = inputData?.sessionDate || inputData?.date || new Date().toISOString().split('T')[0];
    const cptCode = inputData?.cptCode || '90834';
    const duration = inputData?.duration || '45 min';
    const presentingConcerns = inputData?.presentingConcerns || inputData?.chiefComplaint || '';
    const currentSymptoms = inputData?.currentSymptoms || inputData?.symptoms || '';
    const patientReported = inputData?.patientReported || inputData?.subjective || '';
    const clinicalObservations = typeof inputData?.clinicalObservations === 'object'
      ? JSON.stringify(inputData.clinicalObservations)
      : (inputData?.clinicalObservations || inputData?.mse || '');
    const treatmentProvided = inputData?.treatmentProvided || inputData?.interventions || '';
    const progress = inputData?.progress || inputData?.progressSinceLastVisit || '';
    const patientResponse = inputData?.patientResponse || '';
    const followUpPlan = inputData?.followUpPlan || inputData?.plan || '';
    const additionalNotes = inputData?.additionalNotes || '';

    aiPrompt = `You are a licensed clinical psychotherapist / mental health counselor documenting an individual psychotherapy session note.
Patient: ${patientName}
Session Date: ${sessionDate}
CPT Code: ${cptCode} (${duration})
Primary Diagnoses: ${diag || 'Accident-related trauma / Post-Traumatic Stress and Adjustment Disorder'}

Clinical Information Provided by Clinician:
- Presenting Concerns: ${presentingConcerns || 'Not specified'}
- Current Symptoms: ${currentSymptoms || 'Not specified'}
- Patient-Reported Information (Subjective): ${patientReported || 'Not specified'}
- Clinical Observations & Mental Status: ${clinicalObservations || 'Alert, oriented, cooperative'}
- Treatment / Therapeutic Interventions Provided: ${treatmentProvided || 'Cognitive Behavioral Therapy (CBT), psychoeducation, coping skills'}
- Progress Since Previous Visit: ${progress || 'Stable / Ongoing therapeutic engagement'}
- Patient Response to Treatment: ${patientResponse || 'Receptive to therapeutic interventions'}
- Follow-up Plan & Next Steps: ${followUpPlan || 'Continue scheduled psychotherapy sessions'}
- Additional Notes: ${additionalNotes || 'None'}

CRITICAL CLINICAL DOCUMENTATION RULES:
1. Generate an individualized, highly professional clinical progress note using ONLY the clinical facts provided above.
2. DO NOT invent unstated symptoms, medical facts, diagnoses, medications, or patient quotes.
3. If an area was marked as not specified or left blank, indicate that it was not reported or omit it cleanly.
4. Output a valid JSON object ONLY (no markdown backticks, no markdown formatting) with these exact keys:
{
  "subjective": "Thorough professional subjective narrative incorporating presenting concerns, symptoms, and patient-reported state.",
  "mentalStatusExam": "Structured clinical observations of appearance, orientation, mood/affect, speech, thought process, and safety/risk assessment.",
  "interventions": "Detailed therapeutic interventions provided during this session (e.g., CBT techniques, cognitive reframing, somatic regulation).",
  "progressAndResponse": "Clinical assessment of progress since last encounter and patient's response and engagement during this session.",
  "planAndFollowUp": "Clear actionable plan, follow-up schedule, homework/skills practice, and next clinical steps.",
  "fullNoteText": "The complete formatted clinical progress note combining all sections in standardized professional medical format."
}`;
  } else if (promptType === 'COUNSELING_SESSION_NOTES') {
    aiPrompt = `You are a licensed clinical psychotherapist / mental health counselor documenting individual psychotherapy progress notes (CPT 90837, 60 mins) for a patient recovering from a motor vehicle accident.
Generate a valid JSON object ONLY (no markdown, no backticks) with these exact 6 keys:
{
  "session3Text": "Session 3 progress note: Psychoeducation on traumatic stress triggers, cognitive restructuring of collision recall, somatic symptom management (diaphragmatic breathing, 4-7-8 grounding technique). Patient practiced in session.",
  "session4Text": "Session 4 progress note: Identifying and challenging catastrophic cognitive distortions regarding driving and vehicular travel. Behavioral activation and graduated exposure discussed.",
  "session5Text": "Session 5 progress note: Interplay between chronic musculoskeletal pain (cervical/lumbar strain) and emotional distress. Progressive Muscle Relaxation (PMR) adapted for physical injury.",
  "session6Text": "Session 6 progress note: Addressing travel anxiety, vehicular hypervigilance, and insomnia/nightmares secondary to accident trauma. Sleep hygiene protocol established.",
  "session7Text": "Session 7 progress note: Consolidation of cognitive coping mechanisms. Interoceptive desensitization exercises. Patient reports reduced frequency of acute panic episodes during vehicular transit.",
  "session8Text": "Session 8 progress note: Review of therapeutic progress toward functional recovery. Relapse prevention planning, identification of ongoing stress triggers, and self-directed coping strategies."
}
Patient: ${patientName}, Accident Context: ${complaints}, Locations: ${locations}, Diagnoses: ${diag}. Pure JSON only.`;
  } else if (promptType === 'COUNSELING_SESSION_NOTES_PART2') {
    aiPrompt = `You are a licensed clinical psychotherapist / mental health counselor documenting individual psychotherapy progress notes (CPT 90837, 60 mins) for Sessions 9 through 16 for a personal injury patient.
Generate a valid JSON object ONLY (no markdown, no backticks) with these exact 8 keys:
{
  "session9Text": "Session 9 progress note: Cognitive processing of passenger vulnerability and hypervigilance. Exploring maladaptive core beliefs following collision. Somatic pacing practiced.",
  "session10Text": "Session 10 progress note: Graded in-vivo exposure hierarchy planning. Patient navigated moderate traffic as passenger utilizing diaphragmatic pacing to avert panic spikes.",
  "session11Text": "Session 11 progress note: Addressing chronic pain-related demoralization and cognitive fatigue. Pacing techniques and mindful acceptance for cervical/lumbar soft-tissue stiffness.",
  "session12Text": "Session 12 progress note: Driving exposure review. Patient reported driving independently on familiar local roads with manageable distress. Cognitive reframing reinforced.",
  "session13Text": "Session 13 progress note: Consolidation of exposure gains and emotional regulation. Focus on interpersonal distress and communication regarding post-collision functional limitations.",
  "session14Text": "Session 14 progress note: Intermediate treatment review and objective symptom inventory reassessment. Clinically meaningful decrease in GAD-7 anxiety and trauma symptoms.",
  "session15Text": "Session 15 progress note: Generalization of coping tools to highway and night driving conditions. Anticipatory anxiety management and autonomous stress reduction.",
  "session16Text": "Session 16 progress note: Preparation for maintenance and discharge phase. Established detailed individualized relapse prevention blueprint and stabilization coping skills."
}
Patient: ${patientName}, Accident Context: ${complaints}, Locations: ${locations}, Diagnoses: ${diag}. Pure JSON only.`;
  } else if (promptType === 'DAVS_PROGRESS_NOTE') {
    const isPage2 = Number(inputData?.notePage) === 2;
    aiPrompt = `You are a clinical physician documenting a Clinical Progress Evaluation Note (Page ${isPage2 ? '2 of 2' : '1 of 2'}) for a patient receiving Extracorporeal Shockwave Therapy (ESWT) following an accident injury.
Generate a valid JSON object ONLY (no markdown, no backticks) with these exact 4 keys:
{
  "progressStatus": "${isPage2 ? 'Significant Functional Improvement' : 'Moderate Progress / Active Therapy'}",
  "subjective": "${isPage2 ? 'Detailed narrative of mid-to-late course progress, pain reduced to 2-3/10, improved sitting/driving tolerance and ADLs' : 'Detailed narrative of interval progress following initial shockwave therapy, current pain 5-6/10, residual paraspinal tightness'}",
  "objective": "${isPage2 ? 'Objective re-evaluation showing marked reduction in trigger bands, improved tissue pliability, ROM 90-95% normal' : 'Objective evaluation detailing localized taut bands in cervical and lumbar paraspinals, tender trigger points, 15-20% ROM restriction'}",
  "plan": "${isPage2 ? 'Plan to transition to maintenance ESWT, advanced dynamic core exercises, discharge planning in 2-3 weeks' : 'Plan to continue ESWT twice weekly (2.0-2.5 bar, 15 Hz, 2,000 pulses), active-assisted stretching, re-eval in 2 weeks'}"
}
Patient: ${patientName}, Accident Context: ${complaints}, Locations: ${locations}, Diagnoses: ${diag}. Pure JSON only.`;
  } else {
    aiPrompt = `You are an expert clinical medical documentation AI assistant for a US accident & personal injury medical practice. 
Generate a professional, medically precise, structured ${promptType} clinical note draft for an attending physician to review.
Patient Name: ${patientName}
Chief Complaint & Accident Context: ${complaints}
Pain Locations: ${locations}
Section to Generate: ${promptType} (HPI / Physical Exam Summary / Assessment & Plan / Clinical Progress Narrative).
Provide clean, concise medical prose with standard medical terminology and ICD-10 diagnostic implications. Output only the note content.`;
  }

  // 1. If user provided a Google Gemini API Key:
  if (geminiApiKey) {
    try {
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': geminiApiKey
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: aiPrompt }] }]
        })
      });

      if (response.ok) {
        const json = await response.json();
        const aiText = json?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (aiText) {
          const cleanText = aiText.replace(/```json/gi, '').replace(/```/g, '').trim();
          return res.status(200).json({
            draftText: cleanText,
            model: 'Google Gemini 1.5 Flash (Live AI Active)',
            disclaimer: 'AI-generated content is a draft and must be reviewed and approved by an authorized healthcare provider.',
            generatedAt: new Date().toLocaleTimeString()
          });
        }
      } else {
        const errText = await response.text();
        console.warn('Live Gemini API call failed with status:', response.status, errText);
      }
    } catch (err) {
      console.warn('Live Gemini API call failed, using built-in clinical generator:', err.message);
    }
  }

  // 2. If user provided a free Groq API Key:
  if (groqApiKey) {
    try {
      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${groqApiKey}`
        },
        body: JSON.stringify({
          model: 'llama-3.3-70b-versatile',
          messages: [{ role: 'user', content: aiPrompt }]
        })
      });

      if (response.ok) {
        const json = await response.json();
        const aiText = json?.choices?.[0]?.message?.content;
        if (aiText) {
          const cleanText = aiText.replace(/```json/gi, '').replace(/```/g, '').trim();
          return res.status(200).json({
            draftText: cleanText,
            model: 'Groq Llama-3.3-70B (Live Free AI)',
            disclaimer: 'AI-generated content is a draft and must be reviewed and approved by an authorized healthcare provider.',
            generatedAt: new Date().toLocaleTimeString()
          });
        }
      } else {
        const errText = await response.text();
        console.warn('Live Groq API call failed with status:', response.status, errText);
      }
    } catch (err) {
      console.warn('Live Groq API call failed, using built-in clinical generator:', err.message);
    }
  }

  // 3. High-Quality Built-in Clinical Medical Generator (Synthesizes compiled records with 0 external keys needed!)
  let draftText = '';

  if (promptType === 'DOCTOR_NOTE') {
    const sessions = inputData?.totalSessions || inputData?.sessionsCount || '';
    const procedures = inputData?.proceduresList || '';

    // Extract actual documented section text if present in compiled source text
    const extractSection = (regex) => {
      const m = compiledDocs.match(regex);
      return m && m[1] ? m[1].trim() : '';
    };

    const documentedTreatment = extractSection(/(?:treatmentSummary|summaryOfTreatment|treatmentCompleted|treatmentsAdministered|treatmentProvided)[:\s•]+([^\n\r]+)/i);
    const documentedExam = inputData?.examFindings || extractSection(/(?:reexamFindings|objectiveFindings|examFindings|objectiveExam|physicalExam)[:\s•]+([^\n\r]+)/i);
    const documentedImpression = extractSection(/(?:dischargeImpression|diagnosticImpression|permanentImpairment|assessment)[:\s•]+([^\n\r]+)/i);
    const documentedProgress = inputData?.progressSummary || extractSection(/(?:progressNotes|outcome|courseOfCare|clinicalProgress|patientResponse|clinicalNotes)[:\s•]+([^\n\r]+)/i);
    const documentedPlan = inputData?.treatmentPlan || extractSection(/(?:homeExerciseProgram|treatmentPlan|futureCare|goals|planFollowUp)[:\s•]+([^\n\r]+)/i);
    const documentedFollowUp = inputData?.followUp || extractSection(/(?:followUp|dischargeRecommendations|recommendations|clinicalSignOff)[:\s•]+([^\n\r]+)/i);

    // Look for procedure parameters (e.g. TECAR, Laser, ESWT)
    const tecarNote = extractSection(/(?:TECAR|cetPower|retPower|totalTreatmentTime)[:\s•]+([^\n\r]+)/i);
    const laserNote = extractSection(/(?:LASER|ANIK|fluence|joules)[:\s•]+([^\n\r]+)/i);
    const eswtNote = extractSection(/(?:ESWT|radial|totalWaves|barSetting)[:\s•]+([^\n\r]+)/i);

    let synthesizedTreatments = procedures || documentedTreatment;
    if (!synthesizedTreatments) {
      const foundModals = [
        tecarNote ? 'TECAR Therapy (CET/RET)' : '',
        laserNote ? 'Class IV Laser Therapy' : '',
        eswtNote ? 'Extracorporeal Shockwave Therapy (ESWT)' : ''
      ].filter(Boolean);
      if (foundModals.length > 0) {
        synthesizedTreatments = `Administered targeted physical procedures including: ${foundModals.join(', ')}.`;
      } else if (sessions) {
        synthesizedTreatments = `Completed ${sessions} documented treatment session(s) targeting affected anatomical regions.`;
      }
    }

    const isLaserInitial = compiledDocs.includes('Class IV Deep Tissue Laser Therapy Initial Narrative') || compiledDocs.includes('EVALUATION MODALITY: Class IV Deep Tissue Laser');
    const isLaserDischarge = compiledDocs.includes('Class IV Laser Therapy Final Discharge Report') || compiledDocs.includes('DISCHARGE EVALUATION: Class IV Laser');

    let jsonResponse;

    if (isLaserDischarge) {
      jsonResponse = {
        treatmentsAdministered: `The patient has completed a comprehensive, prescribed course of High-Intensity Class IV Deep Tissue Laser Therapy (HILT) consisting of ${sessions || '12 clinical sessions'}. Throughout the therapeutic regimen, treatment was administered utilizing therapeutic dual-wavelength Class IV laser technology (800nm, 10.5W output, average 900 seconds per treatment zone), delivering deep-tissue photobiomodulation to the cervical, thoracic, and lumbar paraspinal musculature.\n\nEach session was paired with certified protective optical eyewear (CPT 10001) and supplemented with adjunctive manual soft-tissue mobilization (CPT 97124). Treatment was consistently well-tolerated with zero documented adverse events, burns, or procedural complications. Cumulative therapeutic energy successfully stimulated soft-tissue regeneration, attenuated local chronic inflammatory mediators, and broke the cycle of reactive muscular splinting.`,
        objectiveFindings: `FINAL OBJECTIVE RE-EXAMINATION:\n- Palpation: Demonstrates marked clinical improvement with substantial resolution of acute myofascial trigger points in the bilateral trapezius, levator scapulae, and lumbar paraspinals. Soft tissues exhibit improved elasticity, compliance, and significant reduction in localized hypertonicity.\n- Range of Motion (ROM): Cervical spine active range of motion is restored to 90-95% of expected physiological normal in all anatomical planes (flexion, extension, bilateral lateral flexion, and rotation) with only minimal stiffness at extreme terminal limits. Lumbar spine range of motion demonstrates 90% recovery with absence of sharp mechanical catching.\n- Neurological Re-Assessment: Motor strength remains 5/5 bilaterally in upper and lower extremities. Sensory perception is intact and symmetrical throughout all dermatomes. Deep tendon reflexes remain 2+ and symmetrical. Straight Leg Raise is negative bilaterally.\n- Pain Severity (VAS): The patient's reported pain rating has significantly decreased from an initial baseline of 7-8/10 down to 1-2/10 (mild, intermittent tightness only).`,
        clinicalAssessment: `DISCHARGE IMPRESSION & PERMANENT IMPAIRMENT:\n1. Resolved Acute Cervical Sprain/Strain (ICD-10 S13.4XXD) with restored mobility and minimal residual tightness.\n2. Resolved Acute Lumbar Sprain/Strain (ICD-10 S33.5XXD) with stabilized paraspinal musculature.\n3. Stable Myofascial Pain Syndrome (ICD-10 M79.1) demonstrating clinically successful response to Class IV photobiomodulation.\n\nMAXIMUM MEDICAL IMPROVEMENT (MMI):\nThe patient has achieved Maximum Medical Improvement (MMI) with respect to the acute traumatic musculoskeletal injuries sustained in the motor vehicle accident. Further intensive formal laser therapy is no longer required at this time as acute clinical stabilization has been reached. In accordance with AMA Guidelines for Evaluation of Permanent Impairment, the patient demonstrates no permanent sensory loss, radiculopathy, or focal motor deficits, resulting in 0% permanent whole-person impairment.`,
        treatmentPlan: `HOME EXERCISE PROGRAM (HEP) & LONG-TERM CARE:\nThe patient has been instructed in, demonstrated proficiency with, and issued an individualized self-directed Home Exercise Program (HEP) designed for long-term postural and muscular maintenance:\n1. Cervical Retraction & Scapular Squeeze: 3 sets of 10 repetitions twice daily to preserve cervicothoracic alignment.\n2. Gentle Dynamic Range-of-Motion: Daily active stretching for cervical lateral flexion and rotation.\n3. Lumbar Pelvic Tilts & Core Stabilization: Floor-based bridging and abdominal bracing 1-2 times daily to safeguard lumbosacral disc integrity.\n4. Ergonomic Guidelines: Educated on proper workstation lumbar support, computer screen eye-level positioning, and taking regular micro-breaks during prolonged sitting or vehicular travel.\n5. Activity Transition: Patient is released to return to pre-accident functional and occupational duties without formal permanent restrictions.`,
        followUp: `CLINICAL DISCHARGE SIGN-OFF:\nThe patient is formally discharged from active Class IV Laser Therapy and restorative care. Treatment records, service line billing statements, and documentation packets have been finalized, verified for medical necessity, and entered into the legal repository. The patient has been educated on flare-up self-management (utilizing ice/heat and prescribed home exercises) and instructed to follow up on a PRN (as-needed) basis should any acute exacerbation of symptoms arise.`
      };
    } else if (isLaserInitial) {
      jsonResponse = {
        chiefComplaint: `The patient presents for comprehensive initial clinical evaluation and initiation of Class IV High-Intensity Laser Therapy (HILT) following involvement in a motor vehicle collision occurring ${inputData?.accidentDate ? `on ${inputData.accidentDate}` : 'recently'}. Upon intake, the patient reports significant, persistent musculoskeletal discomfort localized primarily to the cervical, thoracic, and lumbosacral regions. Chief subjective complaints include: ${complaints || 'cervicalgia, mid-back aching, and lower back stiffness with associated myofascial discomfort'}.\n\nThe pain is characterized as constant, aching, and throbbing, intensifying markedly with prolonged sitting, standing, cervical rotation, and routine activities of daily living (ADLs). Secondary muscular guarding and tension-related cervicogenic headaches are also noted. The patient rates the current pain severity at 7-8/10 on the Visual Analog Scale (VAS), with peak exacerbations reaching 8-9/10 following sustained postural load. Review of systems confirms no loss of bowel/bladder control, progressive focal motor deficit, or constitutional symptoms. Prior conservative self-care measures have yielded only temporary, transient relief.`,
        subjectiveHistory: `Symptoms remain localized to documented spinal regions: ${locations || 'Cervical Spine, Upper Trapezius, and Lumbar Spine'}. The onset of pain was immediate to rapid post-collision, accompanied by progressive morning stiffness, neck and shoulder burning, and difficulty sustaining seated work or vehicular travel.`,
        objectiveFindings: `PHYSICAL EXAMINATION:\nInspection of the cervical and thoracolumbar spine reveals noticeable postural guarding and mild antalgic positioning. Palpation demonstrates marked tenderness and hyperirritable myofascial taut bands with active trigger points throughout the bilateral upper trapezius, levator scapulae, rhomboids, and lumbar paraspinal musculature (L1-S1). Moderate to severe muscular hypertonicity and tissue induration are evident on deep palpation.\n\nRANGE OF MOTION (ROM):\n- Cervical Spine: Flexion restricted to 30°/50°, extension 30°/60°, bilateral lateral flexion restricted to 25°/45°, and bilateral rotation limited to 45°/80° with reported terminal pain and tightness.\n- Lumbar Spine: Flexion limited to 40°/60°, extension 15°/25°, with localized low back discomfort upon terminal extension and lateral bending.\n\nNEUROLOGICAL ASSESSMENT:\n- Motor Strength: Upper and lower extremity motor testing graded 5/5 bilaterally across all major muscle groups (C5-T1, L2-S1).\n- Sensory Testing: Intact and symmetrical to light touch and pinprick across all corresponding dermatomal distributions; no focal sensory deficits.\n- Deep Tendon Reflexes (DTR): Biceps (C5), Brachioradialis (C6), Triceps (C7), Patellar (L4), and Achilles (S1) reflexes are active and symmetrical, graded 2+/4 bilaterally. Straight Leg Raise (SLR) test is negative bilaterally for radiculopathy.`,
        clinicalAssessment: `CLINICAL IMPRESSION:\nBased upon the patient's subjective clinical history, mechanism of traumatic injury from the documented collision, and objective physical examination findings, the clinical impressions are established as follows:\n\n1. Acute Traumatic Cervical Sprain/Strain (ICD-10 S13.4XXA) with associated myofascial hyperirritability and restricted active range of motion.\n2. Acute Traumatic Lumbar Sprain/Strain (ICD-10 S33.5XXA) with paraspinal muscle hypertonicity and mechanical postural intolerance.\n3. Myofascial Pain Syndrome & Trigger Points (ICD-10 M79.1) involving the bilateral cervicothoracic and lumbosacral soft tissues.\n4. Cervicogenic Headaches (ICD-10 G44.209) secondary to upper cervical paraspinal spasm and trapezius contracture.\nDocumented Diagnostic Code References: ${diag || 'M54.2, M54.50, S13.4XXA, S33.5XXA'}.\n\nThe patient's current symptomatic presentation correlates directly with the biomechanical deceleration and acceleration forces sustained during the collision, resulting in micro-tearing of myofascial fibers, localized inflammation, and reactive paraspinal guarding.`,
        treatmentsAdministered: `Administered initial Class IV Deep Tissue Laser Therapy (HILT - CPT 97039) session delivering 800nm dual-wavelength photobiomodulation at 10.5W, paired with mandatory protective eye filtration (CPT 10001) and adjunctive myofascial release (CPT 97124).`,
        courseOfCare: 'Initiating structured multi-modality photobiomodulation care plan. Patient educated on post-treatment hydration, temporary soreness management, and avoidance of heavy eccentric loading.',
        treatmentPlan: `PLAN OF CARE & THERAPEUTIC PROTOCOL:\nIn light of the documented soft-tissue injuries and functional limitations, an aggressive, multi-modality conservative rehabilitation protocol is recommended:\n\n1. High-Intensity Class IV Deep Tissue Laser Therapy (HILT - CPT 97039):\n   - Frequency: 2 to 3 sessions weekly for a recommended duration of 4 to 6 weeks.\n   - Modality Parameters: Dual-wavelength photobiomodulation (800nm continuous wave and pulsed delivery), operating at 10.5 Watts output, delivering approximately 236,250 Joules of therapeutic optical energy across affected cervical, upper thoracic, and lumbosacral paraspinal target zones.\n   - Clinical Objective: Stimulate intracellular cytochrome c oxidase, accelerate mitochondrial ATP synthesis, reduce localized pro-inflammatory cytokines, enhance microcirculation, and stimulate tissue repair.\n2. Protective Eye Protocol (CPT 10001): Mandated safety goggles certified for 800nm attenuation worn by patient and clinician throughout all active laser emissions.\n3. Adjunctive Manual Therapy / Therapeutic Massage (CPT 97124): 15-30 minutes per visit to reduce post-treatment myofascial tension and promote soft-tissue mobilization.\n4. Functional Goals: (a) Reduce VAS pain scores by >= 50% within 4 weeks; (b) Restore cervical and lumbar active range of motion by >= 80%; (c) Enhance seated and vehicular transit tolerance without acute spasm.`,
        followUp: `PROGNOSIS & DISABILITY STATUS:\nThe patient's clinical prognosis for functional recovery is considered FAIR to GOOD, conditioned upon strict adherence to the prescribed Class IV Laser Therapy schedule and active rehabilitation protocol. Given the acute post-traumatic onset, complete tissue remodeling and resolution of deep paraspinal myofascial inflammation typically requires consistent photobiomodulation therapy combined with structured home mobility.\n\nDISABILITY & FUNCTIONAL RESTRICTIONS:\nThe patient is currently moderately disabled with respect to heavy physical exertion and sustained vehicular driving. The following temporary occupational and functional activity modifications are advised for the next 4 weeks:\n- No lifting, carrying, pushing, or pulling in excess of 10-15 lbs.\n- Avoid prolonged uninterrupted sitting or standing exceeding 30-45 minutes without brief postural stretching breaks.\n- Avoid rapid, repetitive cervical extension, rotation, or heavy trunk flexion/twisting.\n- Patient will undergo formal clinical re-evaluation and progress assessment at the conclusion of 4 weeks of active therapy.`
      };
    } else {
      jsonResponse = {
        chiefComplaint: inputData?.chiefComplaint || (complaints ? `Patient presents following documented injury: ${complaints}.` : 'Information not documented in selected records.'),
        subjectiveHistory: inputData?.painDescription || (locations ? `Symptoms localized to documented regions: ${locations}.` : 'Information not documented in selected records.'),
        objectiveFindings: documentedExam || 'Information not documented in selected records.',
        clinicalAssessment: documentedImpression || (diag ? `Documented clinical impression: ${diag}` : 'Information not documented in selected records.'),
        treatmentsAdministered: synthesizedTreatments || 'Information not documented in selected records.',
        courseOfCare: documentedProgress || 'Information not documented in selected records.',
        treatmentPlan: documentedPlan || 'Information not documented in selected records.',
        followUp: documentedFollowUp || 'Information not documented in selected records.'
      };
    }
  } else if (promptType === 'PAIN_MANAGEMENT') {
    const accDate = inputData?.accidentDate || '';
    const accType = inputData?.accidentType || 'motor vehicle collision';
    const jsonResponse = {
      chiefComplaint: `Patient presents for comprehensive pain management evaluation following a ${accType}${accDate ? ` occurring on ${accDate}` : ''}. The patient reports persistent spinal pain, muscle tightness, and associated headaches.`,
      painDescription: ['Sharp', 'Throbbing', 'Aching', 'Radiating'],
      painLocations: locations ? locations.split(',').map(s => s.trim()) : ['Neck', 'L.Back'],
      painCurrent: inputData?.painScore || 7,
      painWorst: 9,
      painBest: 4,
      aggravatingFactors: ['Movement', 'Sitting/Standing', 'Bending', 'Lifting'],
      relievingFactors: ['Rest', 'Ice/Heat', 'Physical therapy'],
      functionalLimitations: ['Difficulty sleeping', 'Reduced daily activities'],
      rosNeurologic: ['Tingling', 'Numbness', 'Headaches'],
      rosMusculoskeletal: ['Joint stiffness', 'Muscle spasms', 'Limited range of motion'],
      palpationTenderness: 'Yes',
      palpationMuscleSpasm: 'Yes',
      rom: 'Limited - Painful',
      neuroMotor: 'Normal',
      neuroSensory: 'Intact',
      neuroReflexes: 'Normal',
      diagnoses: ['S13.4', 'S33.5', 'M79.1', 'M54.1'],
      diagnosticsOrdered: ['MRI', 'X-ray'],
      medications: ['NSAIDs', 'Muscle relaxants'],
      interventions: ['Physical therapy', 'Trigger point injections', 'Laser therapy'],
      restrictions: ['No lifting >10 lbs', 'Limited bending/twisting', 'Gradual return to normal activity'],
      followUp: '2 weeks'
    };
    draftText = JSON.stringify(jsonResponse);
  } else if (promptType === 'TPI_ASSESSMENT') {
    const accDate = inputData?.accidentDate || '';
    const jsonResponse = {
      painScore: inputData?.painScore || 7,
      chiefComplaint: `Patient reports ongoing localized myofascial neck and back pain with acute trigger point tenderness following accident${accDate ? ` on ${accDate}` : ''}. Discomfort radiates into surrounding soft tissue with notable spasm.`,
      affectedMuscles: ['Trapezius (Bilateral)', 'Levator Scapulae', 'Rhomboids', 'Quadratus Lumborum'],
      palpationFindings: 'Palpation reveals discrete, hyperirritable taut bands with localized twitch response and exquisite tenderness in bilateral trapezius and lumbar paraspinal muscles. Jump sign positive on deep pressure.',
      treatmentPlan: 'Perform Trigger Point Injections (CPT 20552/20553) utilizing 1% preservative-free Lidocaine for local desensitization and reduction of myofascial hyperirritability. Follow with targeted stretching exercises and clinical re-evaluation in 1-2 weeks.'
    };
    draftText = JSON.stringify(jsonResponse);
  } else if (promptType === 'TPI_PROCEDURE') {
    const jsonResponse = {
      preOpDiagnosis: diag || 'Myofascial pain syndrome (M79.1), Cervical sprain/strain (S13.4), Lumbar muscle spasm (S33.5)',
      medicationInjected: '1% Lidocaine (preservative-free), 4 mL total',
      totalVolume: '4 mL total volume, 25-gauge 1.5-inch needle',
      musclesInjected: [
        { muscle: 'Trapezius', side: 'Bilateral', volume: '2.0 mL' },
        { muscle: 'Levator Scapulae', side: 'Left / Right', volume: '1.0 mL' },
        { muscle: 'Quadratus Lumborum', side: 'Bilateral', volume: '1.0 mL' }
      ],
      procedureDescription: 'The patient was placed in a comfortable prone/seated position. The target trigger points in the indicated musculature were palpated and marked. The overlying skin was prepped in standard sterile fashion using ChloraPrep. A 25-gauge, 1.5-inch needle was inserted directly into the taut bands of the trigger points. Negative aspiration for blood or bodily fluids was confirmed in multiple planes. A total of 4 mL of 1% preservative-free Lidocaine was injected into the identified trigger points. Local twitch responses were elicited followed by notable relaxation of the muscle band. The needle was withdrawn, and direct hemostatic pressure was applied. Sterile bandages were placed over the injection sites. The patient tolerated the procedure well without immediate adverse events or complications.'
    };
    draftText = JSON.stringify(jsonResponse);
  } else if (promptType === 'COUNSELING_INDIVIDUAL_NOTE' || promptType === 'COUNSELOR_PROGRESS_NOTE') {
    const sessionDate = inputData?.sessionDate || inputData?.date || new Date().toISOString().split('T')[0];
    const cptCode = inputData?.cptCode || '90834';
    const duration = inputData?.duration || '45 min';
    const presentingConcerns = inputData?.presentingConcerns || inputData?.chiefComplaint || 'Patient presents for scheduled behavioral health counseling and psychotherapeutic care.';
    const currentSymptoms = inputData?.currentSymptoms || inputData?.symptoms || 'Vehicular travel anxiety, hyperarousal, and emotional distress following collision.';
    const patientReported = inputData?.patientReported || inputData?.subjective || 'Patient reports ongoing symptoms and discusses recent challenges with daily transit.';
    const clinicalObservations = typeof inputData?.clinicalObservations === 'object' 
      ? Object.entries(inputData.clinicalObservations).map(([k, v]) => `${k}: ${v}`).join('; ')
      : (inputData?.clinicalObservations || inputData?.mse || 'Patient is alert and oriented x4. Affect is constricted but congruent. Speech is normal in rate and rhythm. Denies suicidal/homicidal ideation.');
    const treatmentProvided = inputData?.treatmentProvided || inputData?.interventions || 'Cognitive Behavioral Therapy (CBT) cognitive reframing, psychoeducation on post-trauma stress triggers, and diaphragmatic breathing regulation.';
    const progress = inputData?.progress || inputData?.progressSinceLastVisit || 'Patient demonstrates active participation and comprehension of coping strategies.';
    const patientResponse = inputData?.patientResponse || 'Patient was receptive to therapeutic interventions and engaged constructively in session.';
    const followUpPlan = inputData?.followUpPlan || inputData?.plan || 'Continue individual psychotherapy sessions 1x weekly. Practice grounding and breathing exercises daily.';
    const additionalNotes = inputData?.additionalNotes || '';

    const subjective = `PATIENT REPORT & SUBJECTIVE:\nPatient ${patientName} attended individual psychotherapy (${cptCode}, ${duration}) on ${sessionDate}.\nPresenting Concerns: ${presentingConcerns}\nCurrent Symptoms: ${currentSymptoms}\nPatient Statement: ${patientReported}`;
    const mentalStatusExam = `CLINICAL OBSERVATIONS & MENTAL STATUS:\n${clinicalObservations}\nRisk Assessment: Patient denies suicidal/homicidal ideation, intent, or plan. Cognition is grossly intact.`;
    const interventions = `THERAPEUTIC INTERVENTIONS PROVIDED:\n${treatmentProvided}`;
    const progressAndResponse = `PROGRESS & TREATMENT RESPONSE:\nProgress: ${progress}\nPatient Response: ${patientResponse}`;
    const planAndFollowUp = `TREATMENT PLAN & NEXT STEPS:\n${followUpPlan}${additionalNotes ? `\nAdditional Clinical Notes: ${additionalNotes}` : ''}`;
    const fullNoteText = `BEHAVIORAL HEALTH & PSYCHOTHERAPY PROGRESS NOTE\nPatient: ${patientName} | Date: ${sessionDate} | CPT: ${cptCode} (${duration})\n\n1. SUBJECTIVE:\n${presentingConcerns}\nSymptoms: ${currentSymptoms}\nPatient Statement: ${patientReported}\n\n2. OBJECTIVE / MENTAL STATUS:\n${clinicalObservations}\n\n3. INTERVENTIONS PROVIDED:\n${treatmentProvided}\n\n4. PROGRESS & PATIENT RESPONSE:\nProgress: ${progress}\nPatient Response: ${patientResponse}\n\n5. PLAN & NEXT STEPS:\n${followUpPlan}${additionalNotes ? `\nNotes: ${additionalNotes}` : ''}`;

    draftText = JSON.stringify({
      subjective,
      mentalStatusExam,
      interventions,
      progressAndResponse,
      planAndFollowUp,
      fullNoteText
    });
  } else if (promptType === 'COUNSELING_SESSION_NOTES') {
    const accType = inputData?.accidentType || 'motor vehicle collision';
    const jsonResponse = {
      session3Text: `Session focused on processing acute trauma triggers associated with the ${accType}. Utilized cognitive restructuring to address intrusive thoughts and vehicular hyperarousal. Patient was instructed in somatic grounding and 4-7-8 diaphragmatic breathing to manage sudden distress in transit settings. Patient demonstrated good comprehension and receptivity.`,
      session4Text: `Addressed persistent catastrophic beliefs and driving-related apprehension. Explored avoidance behaviors interfering with daily functional transit. Introduced graduated behavioral exposure strategies and cognitive reframing techniques to reduce anticipatory anxiety. Patient engaged actively in identifying cognitive distortions.`,
      session5Text: `Explored the reciprocal relationship between ongoing physical musculoskeletal pain (cervical and lumbar strain) and elevated psychological distress/frustration. Introduced Progressive Muscle Relaxation (PMR) adapted to avoid physical strain. Patient reported mild tension reduction post-exercise and committed to home practice.`,
      session6Text: `Session targeted sleep disturbance, nighttime trauma hyperarousal, and vehicular transit anxiety. Implemented stimulus control and sleep hygiene principles to address post-accident insomnia and nightmares. Discussed active coping strategies for unexpected passenger distress. Patient exhibited improved insight into emotional triggers.`,
      session7Text: `Reviewed and consolidated cognitive coping mechanisms utilized during recent vehicular transit. Patient reported decreased frequency and intensity of acute anxiety spikes when traveling as a passenger. Continued reinforcement of grounding tools and positive self-talk. Patient demonstrated improved emotional regulation.`,
      session8Text: `Comprehensive review of therapeutic progress and functional gains since initial assessment. Evaluated progress toward treatment plan goals, noting significant reduction in vehicular avoidance. Established a comprehensive relapse prevention plan and self-directed coping regimen for long-term emotional resilience.`
    };
    draftText = JSON.stringify(jsonResponse);
  } else if (promptType === 'COUNSELING_SESSION_NOTES_PART2') {
    const accType = inputData?.accidentType || 'motor vehicle collision';
    const jsonResponse = {
      session9Text: `Focused on cognitive processing of vulnerability and driving fears. Explored catastrophic assumptions regarding bodily fragility following collision. Somatic pacing and grounded mindfulness practiced to neutralize panic reactivity during passenger transit.`,
      session10Text: `Review of graded in-vivo exposure hierarchy. Patient completed short-distance vehicular travel as a passenger under peak traffic conditions. Diaphragmatic pacing and sensory orientation successfully managed anticipatory spikes.`,
      session11Text: `Addressed chronic pain-related demoralization and cognitive fatigue. Explored activity pacing techniques and mindful somatic acceptance for cervical and lumbar soft-tissue stiffness. Patient demonstrated improved coping self-efficacy.`,
      session12Text: `Review of driving exposure homework. Patient reported operating vehicle independently on local routes with manageable distress. Reinforced cognitive reframing of intrusive catastrophic crash recollections.`,
      session13Text: `Consolidation of exposure gains and emotional regulation. Focused on communication with family and employer regarding functional limitations. Patient reported enhanced mood stability and reduced interpersonal irritability.`,
      session14Text: `Intermediate treatment review and objective symptom inventory reassessment. Documented clinically meaningful decreases in GAD-7 anxiety and PCL-5 trauma scores relative to intake baseline.`,
      session15Text: `Generalization of coping tools to highway driving and adverse weather conditions. Reviewed anticipatory anxiety management protocols and autonomous stress-reduction routines. Patient reported increased confidence.`,
      session16Text: `Preparation for transition to maintenance and discharge phase. Established detailed individualized relapse prevention blueprint, identifying high-risk stressors and emergency stabilization tools.`
    };
    draftText = JSON.stringify(jsonResponse);
  } else if (promptType === 'DAVS_PROGRESS_NOTE') {
    const isPage2 = Number(inputData?.notePage) === 2;
    const jsonResponse = isPage2 ? {
      progressStatus: 'Significant Functional Improvement',
      subjective: `Patient presents for follow-up progress evaluation. Reports clinically significant improvement in cervical and lumbar spinal symptoms following course of Extracorporeal Shockwave Therapy (ESWT). Current pain rated 2-3/10 on average. Patient notes substantial gains in functional capacity, sitting tolerance, and driving duration without severe exacerbation. Occasional mild tightness after strenuous activity which resolves with stretching.`,
      objective: `Physical re-examination demonstrates marked reduction in paraspinal muscle hypertonicity and trigger point sensitivity across cervical and lumbar regions. Significantly enhanced soft tissue compliance. Active range of motion (ROM) in cervical and lumbar spine is within 90-95% of expected baseline with minimal end-range discomfort. Motor strength 5/5 bilaterally, deep tendon reflexes symmetrical (2+), no sensory deficits.`,
      plan: `1. Transition from intensive shockwave protocol to maintenance ESWT therapy.\n2. Progress dynamic core strengthening, postural stabilization, and independent home exercise program.\n3. Educate on ergonomic body mechanics and flare-up management.\n4. Comprehensive final outcome evaluation and discharge assessment scheduled in 2-3 weeks.`
    } : {
      progressStatus: 'Moderate Progress / Active Therapy',
      subjective: `Patient presents for clinical progress evaluation following motor vehicle accident. Reports moderate interval reduction in acute cervical and lumbar paraspinal discomfort following initial sessions of Extracorporeal Shockwave Therapy (ESWT). Current pain rated 5-6/10 (improved from initial 8/10). Primary complaints remain muscular stiffness, localized soreness with prolonged sitting or driving, and end-of-day fatigue.`,
      objective: `Palpation reveals discrete hyperirritable myofascial taut bands and active trigger points over the bilateral cervical, upper trapezius, and lumbar paraspinal musculature. Range of motion (ROM) displays moderate restriction (15-20%) secondary to muscular guarding and discomfort at terminal limits. Upper and lower extremity neurological examination remains non-focal. Reflexes 2+ bilaterally.`,
      plan: `1. Continue Extracorporeal Shockwave Therapy (ESWT Radial protocol: 2.0-2.5 bar, 15 Hz, 2,000-2,500 pulses) twice weekly targeting hyperirritable myofascial trigger zones.\n2. Initiate gentle active-assisted stretching and therapeutic exercise for cervical/lumbar mobility.\n3. Postural re-education for seated and driving mechanics.\n4. Clinical re-evaluation of functional progress in 2 weeks.`
    };
    draftText = JSON.stringify(jsonResponse);
  } else if (promptType === 'HPI') {
    draftText = complaints
      ? `HISTORY OF PRESENT ILLNESS:\nPatient presents for evaluation regarding documented injury: ${complaints}.${locations ? ` Symptoms documented in: ${locations}.` : ''}`
      : 'Information not documented in selected records.';
  } else if (promptType === 'EXAM') {
    draftText = inputData?.examFindings
      ? `PHYSICAL EXAMINATION SUMMARY:\n${inputData.examFindings}`
      : 'Information not documented in selected records.';
  } else if (promptType === 'ASSESSMENT') {
    draftText = diag
      ? `CLINICAL ASSESSMENT:\nDocumented diagnoses: ${diag}`
      : 'Information not documented in selected records.';
  } else {
    draftText = inputData?.summary || (complaints
      ? `CLINICAL SUMMARY:\nPatient evaluation for documented injury (${complaints}).`
      : 'Information not documented in selected records.');
  }

  return res.status(200).json({
    draftText,
    model: 'MedCare Clinical AI Engine (Synthesized Records)',
    disclaimer: 'AI-generated content is a draft and must be reviewed and approved by an authorized healthcare provider.',
    generatedAt: new Date().toLocaleTimeString()
  });
};

/**
 * Delete clinical note by ID
 */
export const deleteNote = async (req, res) => {
  const { id } = req.params;

  try {
    const existing = await prisma.clinicalNote.findUnique({
      where: { id }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Clinical note not found.' });
    }

    await prisma.clinicalNote.delete({
      where: { id }
    });

    return res.status(200).json({ message: 'Clinical note deleted successfully.' });
  } catch (error) {
    console.error('Error deleting clinical note:', error);
    return res.status(500).json({ error: 'Failed to delete clinical note.' });
  }
};

